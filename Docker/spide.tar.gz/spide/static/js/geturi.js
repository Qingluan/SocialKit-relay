
        // this is js file for geturi 
        